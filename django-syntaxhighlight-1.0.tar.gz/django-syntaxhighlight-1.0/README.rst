=====
Syntaxhighlight
=====

Syntaxhighlight is a simple Django app to integrate 'Syntax Highlighting in JavaScript'
with the template engine of Django.

Quick start
-----------

1. Add "syntaxhighlight" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'syntaxhighlight',
    ]

2. Include the syntaxhighlight templatetags doing this:

TEMPLATES = [
    {
        ...
        'OPTIONS': {
            'context_processors': [
                ...
            ],
            'builtins': ['syntaxhighlight.templatetags.syntax_highlight'],

And is all done. To use in your template do this:

To the filter knows that is a code, your string need have '@@' in the begin of code,
and the sabe '@@' at end. Doing things that whay you can put text out of @@ and this
will not 'highlited'.

3. On the head of html:
<html>
    <head>
        {% code_script 'python,atom' %}
    ...

Where the first argument is the language and second is the theme,
in this case the language is 'python' and the theme is 'atom'

4. in the body you just need to add the filter "code_body:'python' ", lick this:
{{ some_string|code_body:'python'}}

The argument need be the language used, to code load the javascript that will need.
An imortant thing is that this language must be the same that is in the head of html.

5. And you are done.
