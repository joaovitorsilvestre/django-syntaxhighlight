from django.apps import AppConfig


class SyntaxHighlightConfig(AppConfig):
    name = 'syntax_highlight'
