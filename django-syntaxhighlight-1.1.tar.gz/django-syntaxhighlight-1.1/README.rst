=====
Syntax Highlight
=====

Syntax Highlight is a simple app that has templates tags that intagrate the
highlight made with javasctript to django. And came with the display that
shows the code with line counter and other css stuff. 

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "syntax_highlight" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'syntax_highlight',
    ]

